import 'package:flutter/material.dart';
import 'package:red_blackboard/ui/app.dart';

void main() {
  runApp(const App());
}
