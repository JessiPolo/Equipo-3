// Work Pool service interface
abstract class MisionTicService {
  Future<List> fecthData({int limit, Map map});
}
